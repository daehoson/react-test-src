import React from 'react';

function Footer(props) {
    return (
        <div className='footer'>
            <address>Copyright&copy;2022 React allrights reserved.</address>
        </div>
    );
}

export default Footer;