import React from 'react';
import { Link } from 'react-router-dom';
import dummy from './DB/data.json';

function DayList(props) {
    console.log(dummy)
    return (
        <div>
            <h3>수업목차 출력하기</h3>
            <ul className='list_day'>
                {dummy.days.map((day)=>(
                    <li key={day.id}>
                        <Link to={`/day/${day.day}`}>Day {day.day}</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default DayList;